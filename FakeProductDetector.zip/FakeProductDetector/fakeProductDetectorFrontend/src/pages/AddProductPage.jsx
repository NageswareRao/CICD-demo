import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../services/api'

export default function AddProductPage() {
  const [productName, setProductName] = useState('')
  const [description, setDescription] = useState('')
  const [price, setPrice] = useState('')
  const [error, setError] = useState(null)
  const [saving, setSaving] = useState(false)
  const navigate = useNavigate()

  const onAdd = async (e) => {
    e.preventDefault()
    setError(null)
    setSaving(true)
    try {
      const priceNum = parseFloat(price)
      if (Number.isNaN(priceNum) || priceNum <= 0) {
        setError('Price must be a positive number')
        setSaving(false)
        return
      }
      await api.post('/api/products', { productName, description, price: priceNum })
      navigate('/dashboard')
    } catch (err) {
      const msg = err?.response?.data?.message || err?.message || 'Failed to add product'
      setError(msg)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="container" style={{ maxWidth: 900 }}>
      <div className="topbar">
        <div className="brand">
          <div className="brandTitle">Add Product</div>
          <div className="brandSubtitle">Create a product and generate its QR code</div>
        </div>
        <button className="btn" onClick={() => navigate('/dashboard')}>
          Back
        </button>
      </div>

      <div className="card cardPad">
        <form onSubmit={onAdd} className="grid" style={{ gap: 14 }}>
          <div className="field">
            <label>Product Name</label>
            <input className="input" value={productName} onChange={(e) => setProductName(e.target.value)} />
          </div>

          <div className="field">
            <label>Price</label>
            <input
              className="input"
              type="number"
              min="0"
              step="0.01"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
          </div>

          <div className="field">
            <label>Description</label>
            <textarea
              className="textarea"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <button className="btn btnSuccess" type="submit" disabled={saving}>
            {saving ? 'Creating...' : 'Create + Generate QR'}
          </button>

          {error ? <div className="err">{error}</div> : null}
        </form>
      </div>
    </div>
  )
}
