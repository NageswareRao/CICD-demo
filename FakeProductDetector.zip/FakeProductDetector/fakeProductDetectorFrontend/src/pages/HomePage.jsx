import { useNavigate } from 'react-router-dom'

export default function HomePage() {
  const navigate = useNavigate()

  return (
    <div className="container">
      <div className="topbar">
        <div className="brand">
          <div className="brandTitle">Product Verification</div>
          <div className="brandSubtitle">Scan. Verify. Trust.</div>
        </div>
      </div>

      <div className="hero">
        <div className="card cardPad">
          <h1 className="h1">Verify product authenticity in seconds.</h1>
          <p className="p">
            Scan the QR code on a product to instantly verify whether it is genuine.
            Manufacturers can log in to generate QR codes for newly added products.
          </p>

          <div className="actions">
            <button className="btn btnSuccess" onClick={() => navigate('/verify')}>
              Scan QR to Verify
            </button>
            <button className="btn btnPrimary" onClick={() => navigate('/login')}>
              Manufacturer Login
            </button>
          </div>

          <p className="p" style={{ marginTop: 14 }}>
            New manufacturer?{' '}
            <a className="smallLink" href="/signup">
              Create an account
            </a>
          </p>
        </div>

        <div className="card cardPad">
          <div className="brandTitle">Quick Tips</div>
          <div className="p">
            - Use good lighting for scanning.
            <br />- Keep the QR code centered.
            <br />- If the QR contains a URL, we’ll extract the product id automatically.
          </div>
        </div>
      </div>
    </div>
  )
}
