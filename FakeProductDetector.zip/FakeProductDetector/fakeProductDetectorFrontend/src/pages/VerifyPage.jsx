import { useCallback, useState } from 'react'
import api from '../services/api'
import QrScanner from '../components/QrScanner.jsx'
import { useNavigate } from 'react-router-dom'

export default function VerifyPage() {
  const [scannedProductId, setScannedProductId] = useState(null)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  const onOk = () => {
    setScannedProductId(null)
    setResult(null)
    setError(null)
    navigate('/home')
  }

  const extractProductId = (decodedText) => {
    try {
      const url = new URL(decodedText)
      // Only accept URLs from our domain/localhost that contain /api/verify/
      if (url.pathname.includes('/api/verify/')) {
        const parts = url.pathname.split('/')
        return parts[parts.length - 1]
      }
      // URL from external site - not a valid product QR
      return null
    } catch {
      // Not a URL - check if it's a valid UUID format (product ID)
      const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
      if (uuidPattern.test(decodedText.trim())) {
        return decodedText.trim()
      }
      // Random text - not a valid product QR
      return null
    }
  }

  const onScan = useCallback(
    async (decodedText) => {
      const productId = extractProductId(decodedText)
      if (!productId) {
        setError('Unknown product. This QR is not from our system.')
        return
      }
      if (productId === scannedProductId) return

      setScannedProductId(productId)
      setError(null)
      setResult(null)

      try {
        const res = await api.get(`/api/verify/${productId}`)
        setResult(res.data)
      } catch (e) {
        setError('Unknown product. This QR is not registered in our system.')
      }
    },
    [scannedProductId]
  )

  return (
    <div className="container">
      <div className="topbar">
        <div className="brand">
          <div className="brandTitle">Product Verification</div>
          <div className="brandSubtitle">Verify product authenticity</div>
        </div>
        <button className="btn" onClick={() => navigate('/home')}>
          Home
        </button>
      </div>

      <div className="card cardPad" style={{ maxWidth: 900, margin: '0 auto' }}>
        <div style={{ marginBottom: 16 }}>
          <div className="brandTitle">Public Verification</div>
          <div className="brandSubtitle">Scan a QR code to verify the product</div>
        </div>

        <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', alignItems: 'flex-start' }}>
          <div style={{ flex: '1 1 280px', minWidth: 280 }}>
            <QrScanner onResult={onScan} />
          </div>

          {result ? (
            <div style={{ flex: '1 1 280px', minWidth: 280, paddingLeft: 20, borderLeft: '1px solid rgba(255,255,255,0.1)' }}>
              <div className="brandTitle" style={{ fontSize: 16, color: 'var(--primary2)' }}>✓ Verification Result</div>
              <div className="productMeta" style={{ marginTop: 12 }}>
                <div className="kv">
                  <b>Product Name:</b> {result.productName}
                </div>
                <div className="kv">
                  <b>Price:</b> {result.price}
                </div>
                <div className="kv">
                  <b>Description:</b> {result.description}
                </div>
                <div className="kv">
                  <b>Manufacturer:</b> {result.manufacturerName}
                </div>
                <div className="kv">
                  <b>Status:</b> {result.status}
                </div>
              </div>

              <div className="actions" style={{ marginTop: 16 }}>
                <button className="btn btnSuccess" onClick={onOk}>
                  OK
                </button>
              </div>
            </div>
          ) : null}

          {error ? (
            <div style={{ flex: '1 1 280px', minWidth: 280, paddingLeft: 20, borderLeft: '1px solid rgba(255,255,255,0.1)' }}>
              <div className="err">{error}</div>
              <div className="actions" style={{ marginTop: 16 }}>
                <button className="btn" onClick={onOk}>
                  OK
                </button>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  )
}
