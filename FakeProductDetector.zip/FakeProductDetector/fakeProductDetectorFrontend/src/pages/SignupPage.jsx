import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../services/api'

export default function SignupPage() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const navigate = useNavigate()

  const onSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    setSuccess(null)
    try {
      await api.post('/api/auth/register', { username, password })
      setSuccess('Account created. Please login.')
      setTimeout(() => navigate('/login'), 600)
    } catch (e2) {
      const msg = e2?.response?.data?.message
      setError(msg || 'Failed to create account')
    }
  }

  return (
    <div className="container" style={{ maxWidth: 520 }}>
      <div className="topbar">
        <div className="brand">
          <div className="brandTitle">Create Manufacturer Account</div>
          <div className="brandSubtitle">Sign up to add products and generate QR codes</div>
        </div>
      </div>

      <div className="card cardPad">
        <form onSubmit={onSubmit} className="grid" style={{ gap: 14 }}>
          <div className="field">
            <label>Username</label>
            <input className="input" value={username} onChange={(e) => setUsername(e.target.value)} />
          </div>

          <div className="field">
            <label>Password</label>
            <input
              className="input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button className="btn btnPrimary" type="submit">
            Sign Up
          </button>

          {error ? <div className="err">{error}</div> : null}
          {success ? <div style={{ marginTop: 10, color: 'rgba(255,255,255,0.9)', fontWeight: 700 }}>{success}</div> : null}

          <div className="p" style={{ marginTop: 4 }}>
            Already have an account?{' '}
            <a className="smallLink" href="/login">
              Login
            </a>
          </div>
        </form>
      </div>
    </div>
  )
}
