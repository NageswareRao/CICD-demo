import { useEffect, useState } from 'react'
import api from '../services/api'
import { useAuth } from '../context/AuthContext.jsx'
import { useNavigate } from 'react-router-dom'

export default function DashboardPage() {
  const { logout } = useAuth()
  const navigate = useNavigate()

  const [products, setProducts] = useState([])
  const [error, setError] = useState(null)

  const loadMyProducts = async () => {
    const res = await api.get('/api/products/my')
    setProducts(res.data)
  }

  useEffect(() => {
    loadMyProducts().catch(() => setError('Failed to load products'))
  }, [])

  return (
    <div className="container">
      <div className="topbar">
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <button className="btn btnSuccess" onClick={() => navigate('/add-product')}>
            + Add Product
          </button>
          <div className="brand">
            <div className="brandTitle">Manufacturer Dashboard</div>
            <div className="brandSubtitle">Your products & generated QR codes</div>
          </div>
        </div>

        <button className="btn btnDanger" onClick={logout}>
          Logout
        </button>
      </div>

      {error ? (
        <div className="card cardPad" style={{ marginBottom: 12 }}>
          <div className="err">{error}</div>
        </div>
      ) : null}

      {products.length === 0 ? (
        <div className="card cardPad">No products yet. Click “Add Product” to create one.</div>
      ) : null}

      <div className="products">
        {products.map((p) => (
          <div key={p.productId} className="card productCard">
            <div className="cardPad">
              <div className="brandTitle" style={{ fontSize: 16 }}>
                {p.productName}
              </div>
              <div className="productMeta" style={{ marginTop: 10 }}>
                <div className="kv">
                  <b>Description:</b> {p.description}
                </div>
                <div className="kv">
                  <b>Price:</b> {p.price}
                </div>
                <div className="kv">
                  <b>Product ID:</b> {p.productId}
                </div>
              </div>

              <div style={{ marginTop: 12, display: 'flex', justifyContent: 'center' }}>
                <img src={`http://localhost:8081${p.qrImageUrl}`} alt="QR" className="qr" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
