import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'

export default function LoginPage() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const { login } = useAuth()
  const navigate = useNavigate()

  const onSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    try {
      await login(username, password)
      navigate('/dashboard')
    } catch {
      setError('Invalid username/password')
    }
  }

  return (
    <div className="container" style={{ maxWidth: 520 }}>
      <div className="topbar">
        <div className="brand">
          <div className="brandTitle">Manufacturer Login</div>
          <div className="brandSubtitle">Manage products and generate QR codes</div>
        </div>
        <button className="btn" onClick={() => navigate('/home')}>
          Home
        </button>
      </div>

      <div className="card cardPad">
        <form onSubmit={onSubmit} className="grid" style={{ gap: 14 }}>
          <div className="field">
            <label>Username</label>
            <input className="input" value={username} onChange={(e) => setUsername(e.target.value)} />
          </div>
          <div className="field">
            <label>Password</label>
            <input
              className="input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button type="submit" className="btn btnPrimary">
            Login
          </button>
          {error ? <div className="err">{error}</div> : null}
          <div className="p" style={{ marginTop: 4 }}>
            Don’t have an account?{' '}
            <a className="smallLink" href="/signup">
              Sign Up
            </a>
          </div>
        </form>
      </div>
    </div>
  )
}
