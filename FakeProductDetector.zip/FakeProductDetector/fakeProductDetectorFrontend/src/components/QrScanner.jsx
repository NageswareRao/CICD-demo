import { useEffect, useRef, useState } from 'react'
import { Html5Qrcode } from 'html5-qrcode'

export default function QrScanner({ onResult }) {
  const regionId = useRef(`qr-reader-${Math.random().toString(36).slice(2)}`)
  const qrRef = useRef(null)
  const onResultRef = useRef(onResult)
  const [error, setError] = useState(null)
  const [status, setStatus] = useState('Click Start to open camera')
  const [canStart, setCanStart] = useState(true)
  const startedRef = useRef(false)
  const startPromiseRef = useRef(null)

  useEffect(() => {
    onResultRef.current = onResult
  }, [onResult])

  const startCamera = async () => {
    if (startedRef.current) return
    setError(null)
    setCanStart(false)
    setStatus('Initializing camera…')

    const qr = new Html5Qrcode(regionId.current)
    qrRef.current = qr

    const startPromise = (async () => {
      startedRef.current = true

      const cameraConfig = { facingMode: 'environment' }

      const startWithTimeout = Promise.race([
        qr.start(
          cameraConfig,
          { fps: 10, qrbox: { width: 250, height: 250 } },
          (decodedText) => {
            onResultRef.current?.(decodedText)
          },
          () => {}
        ),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Camera start timed out (8s). Permission denied or no camera available.')), 8000)
        ),
      ])

      await startWithTimeout

      setError(null)
      setStatus('Camera active - Waiting for QR code…')
    })()

    startPromiseRef.current = startPromise

    try {
      await startPromise
    } catch (e) {
      const msg = e?.message ? String(e.message) : 'Failed to start camera'
      setError(msg)
      setStatus('Camera failed')
      setCanStart(true)
      startedRef.current = false

      try {
        qr.clear()
      } catch (_) {}
    }
  }

  useEffect(() => {
    return () => {
      const stopCamera = async () => {
        try {
          await startPromiseRef.current
        } catch (_) {}
        const qr = qrRef.current
        if (!qr) return

        try {
          const state = typeof qr.getState === 'function' ? qr.getState() : null
          const isRunning = state === 2 || state === 'SCANNING'
          if (state != null && isRunning) {
            await qr.stop()
          }
        } catch (_) {}

        try {
          qr.clear()
        } catch (_) {}

        startedRef.current = false
      }
      stopCamera()
    }
  }, [])

  return (
    <div>
      <div id={regionId.current} style={{ width: '100%', maxWidth: 520, minHeight: 320, background: 'rgba(0,0,0,0.2)', borderRadius: 14 }} />
      <div style={{ marginTop: 10 }}>
        {!error && <div className="brandSubtitle">{status}</div>}
        {error && <div className="err">{error}</div>}
        {canStart && (
          <button className="btn btnSuccess" style={{ marginTop: 10 }} onClick={startCamera}>
            Start Camera
          </button>
        )}
        {error && (
          <button className="btn" style={{ marginTop: 10, marginLeft: 8 }} onClick={startCamera}>
            Retry
          </button>
        )}
      </div>
    </div>
  )
}
