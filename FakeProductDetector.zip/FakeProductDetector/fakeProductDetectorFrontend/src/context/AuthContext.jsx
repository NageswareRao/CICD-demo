import React, { createContext, useContext, useMemo, useState } from 'react'
import api from '../services/api'

const AuthContext = createContext(null)

function parseJwt(token) {
  try {
    const payload = token.split('.')[1]
    const json = atob(payload.replace(/-/g, '+').replace(/_/g, '/'))
    return JSON.parse(decodeURIComponent(escape(json)))
  } catch {
    return null
  }
}

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('token'))

  const isTokenValid = useMemo(() => {
    if (!token) return false
    const decoded = parseJwt(token)
    if (!decoded?.exp) return false
    return decoded.exp * 1000 > Date.now()
  }, [token])

  const login = async (username, password) => {
    const res = await api.post('/api/auth/login', { username, password })
    localStorage.setItem('token', res.data.token)
    setToken(res.data.token)
  }

  const logout = () => {
    localStorage.removeItem('token')
    setToken(null)
  }

  const value = {
    token,
    isAuthenticated: isTokenValid,
    login,
    logout
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext)
}
