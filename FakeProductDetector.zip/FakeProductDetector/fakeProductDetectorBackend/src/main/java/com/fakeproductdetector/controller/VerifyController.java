package com.fakeproductdetector.controller;

import com.fakeproductdetector.dto.verify.VerifyResponse;
import com.fakeproductdetector.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/verify")
public class VerifyController {

    private final ProductService productService;

    public VerifyController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/{productId}")
    public ResponseEntity<VerifyResponse> verify(@PathVariable String productId) {
        return ResponseEntity.ok(productService.verify(productId));
    }
}
