package com.fakeproductdetector.controller;

import com.fakeproductdetector.dto.product.AddProductRequest;
import com.fakeproductdetector.dto.product.ProductResponse;
import com.fakeproductdetector.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @PostMapping
    public ResponseEntity<ProductResponse> addProduct(Authentication authentication,
                                                      @Valid @RequestBody AddProductRequest request) {
        return ResponseEntity.ok(productService.addProduct(authentication.getName(), request));
    }

    @GetMapping("/my")
    public ResponseEntity<List<ProductResponse>> myProducts(Authentication authentication) {
        return ResponseEntity.ok(productService.getMyProducts(authentication.getName()));
    }
}
