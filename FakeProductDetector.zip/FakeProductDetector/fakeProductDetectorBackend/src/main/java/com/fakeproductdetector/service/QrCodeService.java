package com.fakeproductdetector.service;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class QrCodeService {

    private final Path qrImagesDir;

    public QrCodeService(@Value("${app.qr.images-dir}") String qrImagesDir) {
        this.qrImagesDir = Path.of(qrImagesDir).toAbsolutePath().normalize();
    }

    public String generatePng(String content, String fileNameNoExt) {
        try {
            Files.createDirectories(qrImagesDir);
            String fileName = fileNameNoExt + ".png";
            Path output = qrImagesDir.resolve(fileName);

            BitMatrix matrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, 300, 300);
            MatrixToImageWriter.writeToPath(matrix, "PNG", output);

            return output.toString();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate QR code", e);
        }
    }

    public String publicQrUrl(String productId) {
        return "/qr-images/" + productId + ".png";
    }
}
