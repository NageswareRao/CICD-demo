package com.fakeproductdetector.service;

import com.fakeproductdetector.dto.product.AddProductRequest;
import com.fakeproductdetector.dto.product.ProductResponse;
import com.fakeproductdetector.dto.verify.VerifyResponse;
import com.fakeproductdetector.entity.Product;
import com.fakeproductdetector.entity.User;
import com.fakeproductdetector.repository.ProductRepository;
import com.fakeproductdetector.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final QrCodeService qrCodeService;

    public ProductService(ProductRepository productRepository,
                          UserRepository userRepository,
                          QrCodeService qrCodeService) {
        this.productRepository = productRepository;
        this.userRepository = userRepository;
        this.qrCodeService = qrCodeService;
    }

    @Transactional
    public ProductResponse addProduct(String username, AddProductRequest request) {
        User manufacturer = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        String productId = UUID.randomUUID().toString();
        String verifyUrl = "http://localhost:8081/api/verify/" + productId;

        String qrImagePath = qrCodeService.generatePng(verifyUrl, productId);

        Product product = new Product();
        product.setProductId(productId);
        product.setProductName(request.getProductName());
        product.setDescription(request.getDescription());
        product.setPrice(request.getPrice());
        product.setManufacturer(manufacturer);
        product.setQrImagePath(qrImagePath);

        productRepository.save(product);

        return toProductResponse(product);
    }

    @Transactional(readOnly = true)
    public List<ProductResponse> getMyProducts(String username) {
        User manufacturer = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        return productRepository.findAllByManufacturerOrderByIdDesc(manufacturer)
                .stream()
                .map(this::toProductResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public VerifyResponse verify(String productId) {
        Product product = productRepository.findByProductId(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));

        BigDecimal price = product.getPrice() != null ? product.getPrice() : BigDecimal.ZERO;

        return new VerifyResponse(
                product.getProductName(),
                product.getDescription(),
                price,
                product.getManufacturer().getUsername(),
                "Genuine Product"
        );
    }

    private ProductResponse toProductResponse(Product product) {
        BigDecimal price = product.getPrice() != null ? product.getPrice() : BigDecimal.ZERO;
        return new ProductResponse(
                product.getProductId(),
                product.getProductName(),
                product.getDescription(),
                price,
                product.getManufacturer().getUsername(),
                qrCodeService.publicQrUrl(product.getProductId())
        );
    }
}
